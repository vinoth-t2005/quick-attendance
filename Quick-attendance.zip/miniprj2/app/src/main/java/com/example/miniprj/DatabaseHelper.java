package com.example.miniprj;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "attendanceDB";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_ATTENDANCE = "attendance";

    // Column names
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_STATUS = "status";

    // Create table SQL query
    private static final String CREATE_TABLE = "CREATE TABLE " + TABLE_ATTENDANCE + " ("
            + COLUMN_DATE + " TEXT, "
            + COLUMN_NAME + " TEXT, "
            + COLUMN_STATUS + " TEXT, "
            + "PRIMARY KEY (" + COLUMN_DATE + ", " + COLUMN_NAME + "));";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ATTENDANCE);
        onCreate(db);
    }

    // Method to mark attendance for a specific date and name
    public void markAttendanceForDate(String date, String name, String status) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_STATUS, status);

        // Use INSERT OR REPLACE to ensure attendance is marked only once per date/name pair
        db.insertWithOnConflict(TABLE_ATTENDANCE, null, values, SQLiteDatabase.CONFLICT_REPLACE);

        db.close();
    }

    // Method to get all names marked for a specific date and status
    public List<String> getNamesForStatus(String date, String status) {
        List<String> names = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = {COLUMN_NAME};
        String selection = COLUMN_DATE + "=? AND " + COLUMN_STATUS + "=?";
        String[] selectionArgs = {date, status};

        Cursor cursor = db.query(TABLE_ATTENDANCE, columns, selection, selectionArgs, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            int nameColumnIndex = cursor.getColumnIndex(COLUMN_NAME);
            if (nameColumnIndex >= 0) {
                do {
                    names.add(cursor.getString(nameColumnIndex));
                } while (cursor.moveToNext());
            } else {
                Log.e("DatabaseHelper", "Column 'name' not found in cursor.");
            }
            cursor.close();
        }

        db.close();
        return names;
    }

    // Method to reset attendance for a specific date
    public void resetAttendanceForDate(String date) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Delete all records for the given date
        db.delete(TABLE_ATTENDANCE, COLUMN_DATE + "=?", new String[]{date});

        db.close();
    }

    // Optional: Method to get all attendance records for a specific date (for viewing purposes)
    public List<String> getAllAttendanceForDate(String date) {
        List<String> attendanceRecords = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = {COLUMN_NAME, COLUMN_STATUS};
        String selection = COLUMN_DATE + "=?";
        String[] selectionArgs = {date};

        Cursor cursor = db.query(TABLE_ATTENDANCE, columns, selection, selectionArgs, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            int nameColumnIndex = cursor.getColumnIndex(COLUMN_NAME);
            int statusColumnIndex = cursor.getColumnIndex(COLUMN_STATUS);

            if (nameColumnIndex >= 0 && statusColumnIndex >= 0) {
                do {
                    String name = cursor.getString(nameColumnIndex);
                    String status = cursor.getString(statusColumnIndex);
                    attendanceRecords.add(name + " - " + status);
                } while (cursor.moveToNext());
            } else {
                Log.e("DatabaseHelper", "Column 'name' or 'status' not found in cursor.");
            }
            cursor.close();
        }

        db.close();
        return attendanceRecords;
    }
}