package com.example.miniprj;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CalendarView;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    private Button goToAttendanceBtn;
    private CalendarView calendarView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        goToAttendanceBtn = findViewById(R.id.goToAttendanceBtn);
        calendarView = findViewById(R.id.calendarView);

        // Set click listener to navigate to attendance page
        goToAttendanceBtn.setOnClickListener(v -> goToAttendance());

        // Set listener for the CalendarView to capture selected date
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            // Format the selected date
            String selectedDate = year + "-" + (month + 1) + "-" + dayOfMonth;

            // Log the selected date for debugging purposes
            Log.d("MainActivity", "Selected Date: " + selectedDate);

            // Create an intent to open AttendanceActivity
            Intent intent = new Intent(MainActivity.this, AttendanceActivity.class);
            intent.putExtra("selectedDate", selectedDate);  // Pass the selected date

            // Start AttendanceActivity with the selected date
            startActivity(intent);
        });
    }

    // Navigate to the Attendance page
    private void goToAttendance() {
        Intent intent = new Intent(MainActivity.this, AttendanceActivity.class);
        startActivity(intent);
    }
}