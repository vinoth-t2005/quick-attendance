package com.example.miniprj;

import java.util.ArrayList;

public class AttendanceRecord {
    private int day;
    private ArrayList<NameStatus> attendanceList;

    public AttendanceRecord(int day, ArrayList<NameStatus> attendanceList) {
        this.day = day;
        this.attendanceList = attendanceList;
    }

    public int getDay() {
        return day;
    }

    public ArrayList<NameStatus> getAttendanceList() {
        return attendanceList;
    }

    public void addAttendance(String name, String status) {
        attendanceList.add(new NameStatus(name, status));
    }

    public void clearAttendance() {
        attendanceList.clear();
    }
}
