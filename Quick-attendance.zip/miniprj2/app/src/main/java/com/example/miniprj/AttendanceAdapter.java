package com.example.miniprj;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class AttendanceAdapter extends RecyclerView.Adapter<AttendanceAdapter.ViewHolder> {

    private final ArrayList<AttendanceRecord> attendanceRecords;
    private OnItemClickListener onItemClickListener;

    public AttendanceAdapter(ArrayList<AttendanceRecord> attendanceRecords) {
        this.attendanceRecords = attendanceRecords;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.onItemClickListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.attendance_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AttendanceRecord record = attendanceRecords.get(position);
        holder.dayText.setText(String.valueOf(record.getDay()));

        StringBuilder attendanceText = new StringBuilder();
        for (NameStatus nameStatus : record.getAttendanceList()) {
            attendanceText.append(nameStatus.getName()).append(" - ").append(nameStatus.getStatus()).append("\n");
        }

        holder.statusText.setText(attendanceText.toString());
    }

    @Override
    public int getItemCount() {
        return attendanceRecords.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView dayText, statusText;

        public ViewHolder(View itemView) {
            super(itemView);
            dayText = itemView.findViewById(R.id.dayText);
            statusText = itemView.findViewById(R.id.statusText);
            itemView.setOnClickListener(v -> {
                if (onItemClickListener != null) {
                    onItemClickListener.onItemClick(getAdapterPosition());
                }
            });
        }
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }
}
