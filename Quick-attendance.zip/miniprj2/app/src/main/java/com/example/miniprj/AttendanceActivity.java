// Updated AttendanceActivity class with DatabaseHelper integration

package com.example.miniprj;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class AttendanceActivity extends AppCompatActivity {

    private EditText nameInput;
    private Button markPresentBtn, markAbsentBtn, markLeaveBtn, markOnDutyBtn, resetBtn, goBackBtn;
    private GridLayout attendanceGrid;
    private DatabaseHelper databaseHelper;

    private String selectedDate; // Date passed from MainActivity

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);

        // Initialize DatabaseHelper
        databaseHelper = new DatabaseHelper(this);

        // Initialize views
        nameInput = findViewById(R.id.nameInput);
        markPresentBtn = findViewById(R.id.markPresentBtn);
        markAbsentBtn = findViewById(R.id.markAbsentBtn);
        markLeaveBtn = findViewById(R.id.markLeaveBtn);
        markOnDutyBtn = findViewById(R.id.markOnDutyBtn);
        resetBtn = findViewById(R.id.resetBtn);
        goBackBtn = findViewById(R.id.goBackBtn);
        attendanceGrid = findViewById(R.id.attendanceGrid);

        // Get the selected date passed from MainActivity (if any)
        selectedDate = getIntent().getStringExtra("selectedDate");
        TextView selectedDateText = findViewById(R.id.selectedDateText);
        selectedDateText.setText("Selected Date: " + selectedDate);

        // Load saved attendance data
        loadAttendanceData();

        // Button Click Listeners
        markPresentBtn.setOnClickListener(v -> markAttendance("Present"));
        markAbsentBtn.setOnClickListener(v -> markAttendance("Absent"));
        markLeaveBtn.setOnClickListener(v -> markAttendance("Leave"));
        markOnDutyBtn.setOnClickListener(v -> markAttendance("On Duty"));

        // Reset Button Click Listener
        resetBtn.setOnClickListener(v -> resetAttendance());

        // Back Button Click Listener (to return to the calendar)
        goBackBtn.setOnClickListener(v -> finish());
    }

    // Method to mark attendance
    private void markAttendance(String status) {
        String name = nameInput.getText().toString().trim();

        if (name.isEmpty()) {
            Toast.makeText(this, "Please enter a name.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Save attendance record for the specific date
        databaseHelper.markAttendanceForDate(selectedDate, name, status);

        // Update the GridLayout to show the current attendance
        updateAttendanceList();

        // Clear the input field for the next name
        nameInput.setText("");
    }

    // Method to update the attendance list in GridLayout
    private void updateAttendanceList() {
        // Clear previous views
        attendanceGrid.removeAllViews();

        // Retrieve and add names under each status
        addNamesToGrid("Present", databaseHelper.getNamesForStatus(selectedDate, "Present"));
        addNamesToGrid("Absent", databaseHelper.getNamesForStatus(selectedDate, "Absent"));
        addNamesToGrid("Leave", databaseHelper.getNamesForStatus(selectedDate, "Leave"));
        addNamesToGrid("On Duty", databaseHelper.getNamesForStatus(selectedDate, "On Duty"));
    }

    // Method to add names to GridLayout under a specific category
    private void addNamesToGrid(String status, List<String> namesList) {
        // Label for the attendance status
        TextView statusLabel = new TextView(this);
        statusLabel.setText(status + ": ");
        statusLabel.setTextSize(18);
        attendanceGrid.addView(statusLabel);

        // Add each name under the respective category
        for (String name : namesList) {
            TextView nameTextView = new TextView(this);
            nameTextView.setText(name);
            nameTextView.setPadding(10, 5, 10, 5);
            attendanceGrid.addView(nameTextView);
        }
    }

    // Method to reset attendance (clear all lists and SQLite data for the date)
    private void resetAttendance() {
        // Remove all data for the current date
        databaseHelper.resetAttendanceForDate(selectedDate);

        // Update the GridLayout
        updateAttendanceList();

        // Clear the input field
        nameInput.setText("");
    }

    // Method to load attendance data from SQLite and display in GridLayout
    private void loadAttendanceData() {
        // Update the GridLayout with the loaded data
        updateAttendanceList();
    }
}